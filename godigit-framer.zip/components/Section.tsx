"use client";
import { motion } from "framer-motion";

export default function Section({ children }: { children: React.ReactNode }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 60, filter: "blur(8px)" }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true }}
      transition={{ duration: 1.2, ease: [0.22,1,0.36,1] }}
    >
      {children}
    </motion.section>
  );
}
