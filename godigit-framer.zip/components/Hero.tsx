"use client";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <motion.section initial={{opacity:0}} animate={{opacity:1}} transition={{duration:1.5}}>
      <motion.h1
        initial={{y:40,opacity:0}}
        animate={{y:0,opacity:1}}
        transition={{delay:0.4,duration:1}}
        style={{fontSize:"4rem",maxWidth:"900px"}}
      >
        Digital infrastructure <span style={{color:"#0473a8"}}>built to scale</span>
      </motion.h1>
      <motion.p
        initial={{y:30,opacity:0}}
        animate={{y:0,opacity:1}}
        transition={{delay:0.8,duration:1}}
        style={{marginTop:30,maxWidth:600,opacity:.8}}
      >
        Premium websites, SaaS and automation systems.
      </motion.p>
    </motion.section>
  );
}
