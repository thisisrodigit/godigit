import Hero from "@/components/Hero";
import Section from "@/components/Section";

export default function Home() {
  return (
    <>
      <Hero />
      <Section><h2>Services</h2><p>Web · SaaS · Automation</p></Section>
      <Section><h2>Process</h2><p>Strategy → Design → Build → Deploy</p></Section>
      <Section><h2>Why GoDigit</h2><p>Fast execution. Clean systems.</p></Section>
      <Section><h2>Projects</h2><p>Custom digital platforms.</p></Section>
      <Section><h2>Contact</h2><p className="blue">Let’s build.</p></Section>
    </>
  );
}
